"""
Agente LangGraph para análisis de inversiones en la bolsa.

Arquitectura:
  Agent (LLM) → tools (datos financieros, noticias, sentimiento, predicciones) → output

El agente recibe una pregunta del usuario sobre dónde invertir, decide qué tools
ejecutar en secuencia, analiza los resultados y produce una recomendación.

Flujo típico:
  1. User pregunta por una/s acción/es específicas
  2. Agent decide qué tools llamar (datos financieros, sentimiento, predicción)
  3. Agent sintetiza todo en una recomendación

Provider intercambiable: cambiar ChatOpenAI → ChatAnthropic → ChatOllama
"""

import getpass
import logging
import os
from typing import Any, Literal

from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_aws import ChatBedrock
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from typing_extensions import Annotated, TypedDict

from agent.mcp_client import get_all_tools

logger = logging.getLogger(__name__)

# ── estado del grafo ────────────────────────────────────────


class AgentState(TypedDict):
    """Estado del agente LangGraph."""
    


# ── factory del agente ──────────────────────────────────────

def _get_llm(
    
    
    
) -> ChatOpenAI:
    """Retorna el LLM configurado. Fácil de intercambiar.

    Para cambiar de provider:
      - Anthropic: from langchain_anthropic import ChatAnthropic
      - Ollama:    from langchain_ollama import ChatOllama
    """
    if provider == "openai":
        api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("DEEPSEEK_API_KEY")
        base_url = os.environ.get("OPENAI_BASE_URL", "https://api.deepseek.com")
        # Intentar DeepSeek si OPENAI_API_KEY no está
        if not os.environ.get("OPENAI_API_KEY"):
            api_key = os.environ.get("DEEPSEEK_API_KEY")
            base_url = "https://api.deepseek.com"

        return ChatOpenAI(
            model=model or "deepseek-chat",
            temperature=temperature,
            api_key=api_key,
            base_url=base_url,
        )

    elif provider == "gemini":
        return ChatGoogleGenerativeAI(
            model=model or "gemini-3.1-flash-lite",
            temperature=temperature,
            google_api_key=os.environ.get("GOOGLE_API_KEY"),
        )

    elif provider == "bedrock":
        return ChatBedrock(
            model=model or "amazon.nova-pro-v1:0",
            temperature=temperature,
            region_name=os.environ.get("AWS_REGION", "us-east-1"),
        )

    # Para agregar provider:
    # elif provider == "anthropic":
    #     from langchain_anthropic import ChatAnthropic
    #     return ChatAnthropic(model=model or "claude-sonnet-4-20250514")
    #
    # elif provider == "ollama":
    #     from langchain_ollama import ChatOllama
    #     return ChatOllama(model=model or "llama3")

    raise ValueError(f"Provider desconocido: {provider}")


SYSTEM_PROMPT = """Eres un ANALISTA DE INVERSIONES SENIOR experto en mercados bursátiles globales (BVC, NYSE, NASDAQ, TSE, LSE, etc.).

Tus herramientas:
1. listar_empresas_por_bolsa(bolsa, limite, sector) — lista empresas disponibles en cualquier bolsa
2. obtener_datos_financieros(ticker) — indicadores clave (P/E, ROE, EBITDA, márgenes)
3. leer_noticias_valora(sector, limite) — noticias financieras (solo BVC/Colombia)
4. analizar_sentimiento_empresas_bvc() — sentimiento de mercado (solo BVC)
5. predict_stock_gru(ticker, ...) — predicción de precios con red neuronal GRU
6. predict_stock_kronos(ticker, ...) — predicción con modelo Kronos
7. ejecutar_scraper_valora(since_days) — inicia scraping de noticias
8. obtener_estado_scraper(job_id) — monitorea scraping

PROTOCOLO PARA CONSULTAS DE INVERSIÓN:
Cuando el usuario pregunte "tengo X dinero, recomiéndame acciones en [bolsa]":

PASO 1 — EXPLORAR: llama a listar_empresas_por_bolsa(bolsa=<bolsa>, limite=30)
         para ver qué empresas están disponibles y sus precios.

PASO 2 — FILTRAR: identifica las mejores 3-5 empresas según fundamentos sólidos
         (P/E razonable, ROE saludable, buen margen neto).
         El precio individual de la acción NO es una restricción — se pueden comprar
         fracciones de acción (shares fraccionarios). El presupuesto total se divide
         en porcentajes, no en cantidades enteras de acciones.

PASO 3 — ANALIZAR: para las 3-5 mejores candidatas, llama obtener_datos_financieros(ticker)
         y revisa: P/E, ROE, márgenes, EBITDA.
         SOLO usa analizar_sentimiento_empresas_bvc si es BVC y hay noticias cargadas.
         NO uses predict_stock_gru ni predict_stock_kronos — son MUY lentos (minutos de entrenamiento).
         Esas tools solo úsalas si el usuario pregunta EXPLÍCITAMENTE por predicciones futuras de precio.

PASO 4 — RECOMENDAR: arma un portafolio con distribución del presupuesto.
         Incluye para cada acción: % del portafolio, monto en $, cantidad de shares
         (pueden ser fraccionarios, ej: 3.7 shares), precio por acción,
         y fundamento de la recomendación.

PROTOCOLO PARA CONSULTAS ESPECÍFICAS (ej: "analiza Ecopetrol"):
1. DATOS FINANCIEROS — obtener_datos_financieros() para P/E, ROE, márgenes
2. SENTIMIENTO — analizar_sentimiento_empresas_bvc() para ver el humor del mercado (solo BVC)
3. CONCLUSIÓN — sintetiza todo en recomendación.
   NO uses predict_stock_gru ni predict_stock_kronos a menos que el usuario pregunte
   explícitamente por predicción de precio futuro.

CRITERIOS DE ANÁLISIS:
- VALORACIÓN: ¿P/E alto o bajo vs sector? ¿Forward P/E mejora?
- RENTABILIDAD: ¿ROE > costo de capital (~12-15% para Colombia, ~8-10% para USA)?
- EFICIENCIA: margen neto saludable?
- SENTIMIENTO: ¿noticias positivas o negativas?
- TENDENCIA TÉCNICA: ¿qué indica la predicción?
- DIVERSIFICACIÓN: ¿estás concentrando riesgo en un solo sector?

IMPORTANTE: tu respuesta final debe ser una recomendación CLARA y ACCIONABLE.
Incluye: recomendación (COMPRAR / MANTENER / VENDER / NO INVERTIR),
fundamento (por qué), riesgos identificados, distribución del portafolio (si aplica),
y precio objetivo si aplica.

Sé crítico y riguroso como un analista con 20 años de experiencia en mercados globales.
SIEMPRE responde en español."""


def create_agent(
    
    
    
):
    """Crea el grafo LangGraph del agente de inversiones.

    Args:
        provider: "openai" | "anthropic" | "ollama"
        model: nombre del modelo (default: deepseek-chat para openai)
        temperature: creatividad del modelo (default: 0.3 para análisis serio)
    """
    # ── tools ───────────────────────────────────────────────
    
    

    # ── LLM ─────────────────────────────────────────────────
    
    

    # ── nodos ───────────────────────────────────────────────

    def analista(state: AgentState, config: RunnableConfig):
        """Nodo principal: el LLM decide qué hacer."""
        
        
        
        return {"messages": [response]}

    def should_continue(state: AgentState) -> Literal["tools", END]:
        """Decide si seguir llamando tools o responder al usuario."""
        last_msg = state["messages"][-1]
        if hasattr(last_msg, "tool_calls") and last_msg.tool_calls:
            return "tools"
        return END

    # ── construir grafo ─────────────────────────────────────
    

    
    

    
    
    

    # Memoria para mantener conversación
    memory = MemorySaver()

    return graph.compile(checkpointer=memory)


# ── CLI directo ────────────────────────────────────────────

async def ask(query: str, **kwargs):
    """Consulta rápida al agente. Para uso interactivo desde CLI."""
    agent = create_agent(**kwargs)
    config = RunnableConfig(configurable={"thread_id": "cli-session"})
    result = await agent.ainvoke(
        {"messages": [HumanMessage(content=query)]},
        config,
    )
    return result["messages"][-1].content

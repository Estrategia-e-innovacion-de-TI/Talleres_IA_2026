"""
MCP tool wrappers — expone las funciones del MCP server como LangChain tools
listas para usar con LangGraph.

En lugar de lanzar un subproceso MCP, wrappeamos las funciones directamente
(están decoradas con @mcp.tool() en server/mcp_server.py). Esto evita:
- La latencia de init del modelo Kronos en cada startup
- La complejidad del protocolo JSON-RPC sobre subproceso
- Dependencias extra (langchain-mcp-adapters)

Para cambiar a subproceso real en el futuro, solo reemplazar este módulo.
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

import requests
from dotenv import load_dotenv

import yfinance as yf
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)

# ── imports diferidos para evitar bloqueos ──────────────────

_SENTIMIENTO_CACHE: dict[str, Any] = {}
_SCRAPER_LOCK = asyncio.Lock()

# Cargar .env
load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# Mapa de bolsas → exchange code en FMP (reservado para uso futuro)
EXCHANGE_MAP = {
    "BVC": "BVC",
    "NYSE": "NYSE",
    "NASDAQ": "NASDAQ",
    "TSE": "TSE",         # Tokyo
    "LSE": "LSE",         # London
    "TSX": "TSX",         # Toronto
    "XETRA": "XETRA",     # Frankfurt/Xetra
    " Euronext": "EURONEXT",
}


def _get_project_root() -> Path:
    return Path(__file__).resolve().parent.parent


# ── helpers ─────────────────────────────────────────────────

TICKER_MAP = {
    "BANCOLOMBIA": "CIB.CL",
    "BANCOLOMBIA_PREF": "PFCIB.CL",
    "ECOPETROL": "EC.CL",
    "GRUPO_SURA": "GRUPOSURA.CL",
    "ISA": "ISA.CL",
    "NUTRESA": "NUTRESA.CL",
    "CEMARGOS": "CEMARGOS.CL",
    "PFAVAL": "PFAVAL.CL",
    "BVC": "BVC.CL",
    "CORFERIAS": "CORFERIAS.CL",
    "GRUPO_ARGOS": "ARGOS.CL",
    "GRUPO_BOLIVAR": "BOLIVAR.CL",
    "MINEROS": "MINEROS.CL",
    "TABLEMAC": "TABLEMAC.CL",
    "TERPEL": "TERPEL.CL",
    "ETB": "ETB.CL",
    "CONCONCRET": "CONCONCRET.CL",
    "COLTEL": "COLTEL.CL",
    "COLMOTORES": "COLMOTORES.CL",
    "FABRICATO": "FABRICATO.CL",
    "PROCESION": "PROCESION.CL",
    "PROMIGAS": "PROMIGAS.CL",
    "CELSIA": "CELSIA.CL",
    "EEB": "EEB.CL",
    "BOGOTA": "BOGOTA.CL",
    "OCCIDENTE": "OCCIDENTE.CL",
    "POPULAR": "POPULAR.CL",
    "BBVA_COLOMBIA": "BBVACOL.CL",
    "AVAL": "AVAL.CL",
    "CORPBANCA": "CORPBANCA.CL",
    "DAVIVIENDA": "DAVIVIENDA.CL",
    "GRUPOSURA": "GRUPOSURA.CL",
    "SURA": "SURA.CL",
    "PROTECCION": "PROTECCION.CL",
    "COLPATRIA": "COLPATRIA.CL",
    "BOLSA_NY": "BOLSANY.CL",
    "CARVAJAL": "CARVAJAL.CL",
    "CARTON_COLOMBIA": "CARTON.CL",
    "CEMENTOS_ARGOS": "CEMARGOS.CL",
    "COLINVERS": "COLINVERS.CL",
    "CONSTRUCCIONES": "CONSTRUC.CL",
    "ELECTRIFICADORA": "ELECTRIF.CL",
    "EMPAQUES": "EMPAQUES.CL",
    "ENKA": "ENKA.CL",
    "EXITO": "EXITO.CL",
    "FENIX": "FENIX.CL",
    "GAS_NATURAL": "GASNAT.CL",
    "GRUPO_NUTRESA": "NUTRESA.CL",
    "GRUPO_ORBIS": "ORBIS.CL",
    "HELM_BANK": "HELM.CL",
    "INDUSTRIAS": "INDUSTRIAS.CL",
    "ISAGEN": "ISAGEN.CL",
    "ODEBRECHT": "ODEBRECHT.CL",
    "PAZ_RIO": "PAZRIO.CL",
    "SIDERURGICA": "SIDERURG.CL",
    "SISTEMAS": "SISTEMAS.CL",
    "SOCIEDAD_PORTUARIA": "PUERTO.CL",
    "TECNOQUIMICAS": "TECNOQ.CL",
    "TITAN": "TITAN.CL",
    "VALORES_SIMESA": "VSIMESA.CL",
}


def _resolver_ticker(ticker: str) -> str:
    """Normaliza ticker local → Yahoo Finance.
    Si el ticker está en el mapa colombiano (BVC), devuelve el .CL.
    Si ya tiene punto (ej: EC.CL, KO), lo deja igual.
    Si no está en ningún mapa, lo devuelve tal cual (para NYSE/NASDAQ/etc.)."""
    t = (ticker or "").strip().upper()
    if not t:
        return ""
    if t in TICKER_MAP:
        return TICKER_MAP[t]
    if "." in t:
        return t
    return t


# ── tool functions ──────────────────────────────────────────

async def listar_empresas_por_bolsa(
    bolsa: str = "BVC",
    limite: int = 30,
    sector: Optional[str] = None,
) -> str:
    """Lista empresas disponibles en una bolsa desde una base local + precios en vivo de Yahoo Finance.

    Args:
        bolsa: Código de la bolsa. Ej: 'BVC' (Colombia), 'NYSE', 'NASDAQ',
               'TSE' (Tokyo), 'LSE' (Londres).
        limite: Máximo de empresas a retornar (default: 30).
        sector: Filtrar por sector (opcional). Ej: 'Financial', 'Energy',
               'Technology', 'Utilities'.
    """
    bolsa_key = bolsa.upper().strip()
    base_path = Path(__file__).resolve().parent / "empresas_por_bolsa.json"
    if not base_path.exists():
        return (f"❌ No se encontró el archivo de empresas. Esperado en:\n"
                f"   {base_path}")

    try:
        with open(base_path, encoding="utf-8") as f:
            catalogo = json.load(f)
    except Exception as e:
        return f"❌ Error al cargar catálogo de empresas: {e}"

    if bolsa_key not in catalogo:
        disponibles = ", ".join(k for k in catalogo if not k.startswith("_"))
        return f"❌ Bolsa '{bolsa}' no encontrada. Disponibles: {disponibles}"

    empresas = catalogo[bolsa_key]
    if sector:
        sector_lower = sector.lower()
        empresas = [e for e in empresas if e.get("sector", "").lower() == sector_lower]

    if not empresas:
        return f"📭 No se encontraron empresas para {bolsa}{f' en sector {sector}' if sector else ''}."

    # Tomar las primeras N según límite
    empresas = empresas[:limite]

    # Obtener precios en vivo via yfinance
    tickers_str = " ".join(e["symbol"] for e in empresas)
    try:
        tickers_data = yf.Tickers(tickers_str)
        precios = {}
        for sym in [e["symbol"] for e in empresas]:
            try:
                t = tickers_data.tickers.get(sym)
                if t:
                    info = t.info
                    precios[sym] = {
                        "price": info.get("currentPrice") or info.get("regularMarketPrice"),
                        "change": info.get("regularMarketChangePercent"),
                    }
            except Exception:
                pass
    except Exception:
        precios = {}

    lines = [
        f"📋 EMPRESAS EN {bolsa_key}",
        "=" * 70,
        f"Total: {len(empresas)} empresas" + (f" (filtro: {sector})" if sector else ""),
        "",
        f"{'Ticker':<18} {'Nombre':<35} {'Precio':>10} {'Cambio':>8} {'Sector':<22}",
        "-" * 70,
    ]
    for e in empresas:
        sym = e["symbol"]
        nombre = (e.get("name", "") or "")[:34]
        sector_str = (e.get("sector", "") or "")[:21]
        p = precios.get(sym, {})
        precio = p.get("price")
        cambio = p.get("change")
        precio_str = f"${precio:,.2f}" if precio else "N/D"
        cambio_str = f"{cambio*100:+.2f}%" if cambio else ""
        lines.append(f"{sym:<18} {nombre:<35} {precio_str:>10} {cambio_str:>8} {sector_str:<22}")

    lines.append(f"\n💡 Usa obtener_datos_financieros('{empresas[0][chr(115)+chr(121)+chr(109)+chr(98)+chr(111)+chr(108)]}') para analizar una en detalle.")
    return "\n".join(lines)

async def leer_noticias_valora(
    archivo: Optional[str] = None,
    sector: Optional[str] = None,
    limite: Optional[int] = None,
) -> str:
    """Lee y filtra las noticias extraídas por el scraper de Valora Analitik.
    Args:
        archivo: Ruta del archivo JSON (usa el más reciente si no se especifica)
        sector: Filtrar por sector (ej: financiero, minero_energetico, construccion)
        limite: Número máximo de noticias a retornar
    """
    try:
        project = _get_project_root()
        if not archivo:
            jsons = list(project.glob("noticias_valora_*.json"))
            if not jsons:
                return "No hay archivos de noticias. Ejecuta ejecutar_scraper_valora primero."
            archivo = max(jsons, key=lambda p: p.stat().st_mtime)
        else:
            archivo = Path(archivo)

        with open(archivo, encoding="utf-8") as f:
            noticias = json.load(f)

        if not isinstance(noticias, list):
            noticias = [noticias]

        if sector:
            noticias = [n for n in noticias if sector in n.get("sectores", [])]
        if limite:
            noticias = noticias[:limite]

        return json.dumps(noticias, ensure_ascii=False, indent=2)

    except Exception as e:
        return f"Error al leer noticias: {e}"


async def analizar_sentimiento_empresas_bvc(
    archivo: Optional[str] = None,
) -> str:
    """Analiza sentimiento de noticias para empresas de la BVC.
    Detecta empresas mencionadas y clasifica cada noticia como POSITIVA/NEGATIVA/NEUTRAL
    basado en palabras clave financieras en español.

    Args:
        archivo: Ruta del JSON de noticias (usa el más reciente si se omite)
    """
    try:
        project = _get_project_root()

        # Cargar empresas BVC
        import sys
        scraper_path = project / "scraper"
        if str(scraper_path) not in sys.path:
            sys.path.insert(0, str(scraper_path))
        from empresas_bvc import buscar_empresas_en_texto, obtener_info_empresa

        # Determinar archivo
        if not archivo:
            jsons = list(project.glob("noticias_valora_*.json"))
            if not jsons:
                return "No hay archivos de noticias."
            archivo = max(jsons, key=lambda p: p.stat().st_mtime)
        else:
            archivo = Path(archivo)

        with open(archivo, encoding="utf-8") as f:
            noticias = json.load(f)
        if not isinstance(noticias, list):
            noticias = [noticias]

        positivas = [
            "crecimiento", "aumento", "éxito", "ganancia", "beneficio", "inversión",
            "expansión", "mejora", "récord", "avance", "positivo", "fortalece",
            "impulsa", "optimismo", "recuperación", "incremento", "alza", "subió",
            "logro", "sube", "rentabilidad", "utilidad", "dividendo", "superó",
            "supera", "destaca", "lidera", "liderazgo", "sólido", "robusto",
        ]
        negativas = [
            "crisis", "pérdida", "caída", "disminución", "reducción", "problema",
            "dificultad", "riesgo", "amenaza", "recorte", "despido", "cierre",
            "baja", "bajó", "cae", "cayó", "negativo", "preocupación", "incertidumbre",
            "débil", "debilidad", "deterioro", "menor", "multa", "sanción",
            "demanda", "controversia", "investigación", "pérdidas", "declive",
            "afectación", "presión",
        ]

        analisis: dict[str, Any] = {}

        for noticia in noticias:
            texto = f"{noticia.get('titulo', '')} {noticia.get('contenido', '')}".lower()
            tickers = buscar_empresas_en_texto(texto)

            for ticker in tickers:
                info = obtener_info_empresa(ticker)
                if ticker not in analisis:
                    analisis[ticker] = {
                        "ticker": ticker,
                        "empresa": info["nombre_completo"],
                        "sector": info["sector"],
                        "noticias": [],
                        "positivas": 0, "negativas": 0, "neutrales": 0,
                    }

                sp = sum(1 for p in positivas if p in texto)
                sn = sum(1 for n in negativas if n in texto)

                if sp > sn:
                    sent = "POSITIVO"
                    analisis[ticker]["positivas"] += 1
                elif sn > sp:
                    sent = "NEGATIVO"
                    analisis[ticker]["negativas"] += 1
                else:
                    sent = "NEUTRAL"
                    analisis[ticker]["neutrales"] += 1

                analisis[ticker]["noticias"].append({
                    "titulo": noticia.get("titulo", ""),
                    "fecha": noticia.get("fecha", ""),
                    "sentimiento": sent,
                    "url": noticia.get("url", ""),
                })

        # Resumen
        resultado = sorted(analisis.values(), key=lambda x: len(x["noticias"]), reverse=True)
        lines = ["📊 ANÁLISIS DE SENTIMIENTO - BVC", "=" * 60, ""]
        for r in resultado:
            total = len(r["noticias"])
            pct_pos = round(r["positivas"] / total * 100, 1) if total else 0
            pct_neg = round(r["negativas"] / total * 100, 1) if total else 0

            if r["positivas"] > r["negativas"] + r["neutrales"] * 0.5:
                icono = "🟢"
                val = "POSITIVA"
            elif r["negativas"] > r["positivas"] + r["neutrales"] * 0.5:
                icono = "🔴"
                val = "NEGATIVA"
            else:
                icono = "🟡"
                val = "NEUTRAL"

            lines.append(f"{icono} {r['empresa']} ({r['ticker']}) — {val}")
            lines.append(f"   Sector: {r['sector']}  |  Noticias: {total}")
            lines.append(f"   {pct_pos}% pos / {pct_neg}% neg / {round(100-pct_pos-pct_neg,1)}% neu")
            lines.append("")

        return "\n".join(lines)

    except Exception as e:
        return f"Error en análisis de sentimiento: {e}"


async def obtener_datos_financieros(ticker: str) -> str:
    """Obtiene indicadores financieros clave de una empresa via Yahoo Finance.

    IMPORTANTE: actúa como ANALISTA SENIOR. Interpreta los números:
    - P/E Ratio: ¿está cara o barata vs el sector/crecimiento?
    - ROE: ¿el retorno supera el costo de capital?
    - Margen neto: eficiencia operativa
    - EBITDA y Free Cash Flow: salud financiera

    Args:
        ticker: Símbolo bursátil (ej: EC.CL, PFAVAL.CL, CIB.CL, GRUPOSURA.CL)
    """
    try:
        ticker_yf = _resolver_ticker(ticker)
        empresa = yf.Ticker(ticker_yf)
        info = empresa.info

        def v(key):
            val = info.get(key)
            if val is None:
                return "N/D"
            if isinstance(val, float):
                return f"{val:.4f}" if abs(val) < 1 else f"{val:,.2f}"
            return str(val)

        lines = [
            f"📋 DATOS FINANCIEROS — {info.get('longName', ticker_yf)} ({ticker_yf})",
            "=" * 60,
            f"💰 Precio: {v('currentPrice')} {v('currency')}",
            f"🏢 Market Cap: {v('marketCap')}",
            f"📊 Sector: {v('sector')}  |  Industria: {v('industry')}",
            "",
            "📈 RENTABILIDAD:",
            f"   Margen Neto: {v('profitMargins')}",
            f"   ROE: {v('returnOnEquity')}",
            "",
            "💵 VALORACIÓN:",
            f"   P/E (trailing): {v('trailingPE')}",
            f"   P/E (forward):  {v('forwardPE')}",
            "",
            "💶 FLUJOS:",
            f"   EBITDA: {v('ebitda')}",
            f"   Cashflow Operativo: {v('operatingCashflow')}",
            f"   Free Cash Flow: {v('freeCashflow')}",
            "=" * 60,
        ]
        return "\n".join(lines)

    except Exception as e:
        return f"Error al obtener datos de {ticker}: {e}"


async def predict_stock_gru(
    ticker: str,
    start_date: str,
    end_date: str,
    lookback: int = 30,
    pred_len: int = 5,
) -> str:
    """Predice precios de acciones usando modelo GRU (deep learning).

    Entrena una red GRU con datos históricos y genera pronóstico.
    Args:
        ticker: Ticker de Yahoo Finance (ej: PFAVAL.CL, EC.CL, AAPL)
        start_date: Fecha inicio histórico (YYYY-MM-DD)
        end_date: Fecha fin histórico (YYYY-MM-DD)
        lookback: Días de contexto histórico (default: 30)
        pred_len: Días a predecir (default: 5)
    """
    try:
        from server.analisis_tecnico import run_gru_prediction
        ticker_yf = _resolver_ticker(ticker)

        result = run_gru_prediction(
            ticker=ticker_yf,
            start_date=start_date,
            end_date=end_date,
            lookback=lookback,
            pred_len=pred_len,
        )

        lines = [
            f"🔮 PREDICCIÓN GRU — {ticker_yf}",
            "=" * 60,
            f"📊 MAE: {result['metrics']['mae']:.4f}",
            f"📊 RMSE: {result['metrics']['rmse']:.4f}",
            "",
            f"💰 Próximo cierre estimado ({result['next_business_day_prediction']['date']}):",
            f"   ${result['next_business_day_prediction']['predicted_close']:,.2f}",
            "",
            "📅 Pronóstico extendido:",
        ]
        for f in result["future_forecast"]:
            lines.append(f"   {f['date']}: ${f['predicted_close']:,.2f}")

        lines.append(f"\n📈 Gráfico: {result['chart_path']}")
        return "\n".join(lines)

    except Exception as e:
        return f"Error en predicción GRU: {e}"


async def predict_stock_kronos(
    ticker: str,
    start_date: str,
    end_date: str,
    lookback: int = 343,
    pred_len: int = 7,
) -> str:
    """Predice precios y volumen usando el modelo Kronos (time-series foundation model).

    Kronos es un modelo fundacional de series temporales fine-tuneado para
    predicción financiera. Requiere ~1 año de datos históricos.

    Args:
        ticker: Ticker de Yahoo Finance (ej: PFAVAL.CL, EC.CL)
        start_date: Fecha inicio (YYYY-MM-DD)
        end_date: Fecha fin (YYYY-MM-DD)
        lookback: Ventana de contexto (default: 343 ≈ 1 año hábil)
        pred_len: Días a predecir (default: 7)
    """
    try:
        # Import diferido — Kronos carga el modelo en import
        from server.model_kronos import run_kronos_prediction

        ticker_yf = _resolver_ticker(ticker)

        result = run_kronos_prediction(
            ticker=ticker_yf,
            start_date=start_date,
            end_date=end_date,
            lookback=lookback,
            pred_len=pred_len,
        )

        lines = [
            f"🔮 PREDICCIÓN KRONOS — {ticker_yf}",
            "=" * 60,
        ]
        for f in result.get("forecast", []):
            lines.append(f"   {f.get('date', '?'):12s}  Close: ${f.get('close', 0):>10,.2f}  "
                         f"Volume: {f.get('volume', 0):>14,}")

        lines.append(f"\n📈 Gráfico: {result.get('chart_path', 'N/A')}")
        return "\n".join(lines)

    except Exception as e:
        return f"Error en predicción Kronos: {e}"


async def ejecutar_scraper_valora(
    since_days: int = 5,
) -> str:
    """Inicia el scraper de Valora Analitik para obtener noticias financieras.
    Corre en background. Usa obtener_estado_scraper para consultar avance.

    Args:
        since_days: Días hacia atrás (default: 5, max: 365)
    """
    try:
        import subprocess
        project = _get_project_root()

        job_id = datetime.now().strftime("%H%M%S")
        log_file = project / f"scraper_{job_id}.log"
        output_file = project / f"noticias_valora_{since_days}dias.json"

        cmd = [
            str(project / ".venv" / "Scripts" / "python.exe"),
            "-m", "scrapy", "runspider",
            str(project / "scraper" / "valora_spider.py"),
            "-a", f"since_days={since_days}",
            "-O", str(output_file),
            "--logfile", str(log_file),
        ]

        async def _run():
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
                cwd=str(project),
            )
            # No await — lanzamos en background
            return proc

        proc = await _run()
        # Devolver info sin esperar
        return (
            f"🔄 Scraper iniciado.\n"
            f"   Job ID: {job_id}\n"
            f"   Días: {since_days}\n"
            f"   Salida: {output_file.name}\n"
            f"   Log: scraper_{job_id}.log\n\n"
            f"   Consulta estado con: obtener_estado_scraper(job_id=\"{job_id}\")\n"
            f"   ⏱ Estima 3-10 minutos"
        )

    except Exception as e:
        return f"Error al iniciar scraper: {e}"


async def obtener_estado_scraper(
    job_id: Optional[str] = None,
) -> str:
    """Consulta el estado de un trabajo de scraping o lista todos.

    Args:
        job_id: ID del trabajo (opcional, muestra todos si no se especifica)
    """
    project = _get_project_root()
    log_files = sorted(project.glob("scraper_*.log"))

    if not log_files:
        return "📭 No hay trabajos de scraping."

    # Si no hay job_id, mostrar resumen
    if not job_id:
        lines = ["📋 TRABAJOS DE SCRAPING", "=" * 40]
        for lf in reversed(log_files):
            jid = lf.stem.replace("scraper_", "")
            # Ver si hay output correspondiente
            lines.append(f"   📄 {jid}  ({lf.stat().st_size} bytes)")
        return "\n".join(lines)

    # Buscar log específico
    log_file = project / f"scraper_{job_id}.log"
    if not log_file.exists():
        return f"❌ No se encontró el trabajo con ID: {job_id}"

    with open(log_file, encoding="utf-8", errors="replace") as f:
        lines_log = f.readlines()

    # Buscar líneas relevantes
    relevant = [l.strip() for l in lines_log
                if any(k in l for k in ["Crawled", "Scraped", "Spider opened", "Spider closed"])]

    output_file = project / f"noticias_valora_5dias.json"
    num_arts = 0
    if output_file.exists():
        try:
            with open(output_file, encoding="utf-8") as f:
                num_arts = len(json.load(f))
        except Exception:
            pass

    estado = "completado" if "Spider closed" in "\n".join(lines_log[-5:]) else "ejecutando"

    return (
        f"{'✅' if estado == 'completado' else '⚙️'} Estado: {estado.upper()}\n"
        f"📋 Job ID: {job_id}\n"
        f"📊 Artículos: {num_arts}\n"
        f"📄 Log: {log_file.name}\n\n"
        f"📺 Últimas líneas:\n" + "\n".join(relevant[-5:]) + "\n"
        if relevant else "   (sin líneas relevantes aún)"
    )


# ── factory ─────────────────────────────────────────────────

def get_all_tools() -> list[StructuredTool]:
    """Retorna todas las herramientas financieras como LangChain StructuredTool."""

    tools = [
        StructuredTool.from_function(
            coroutine=listar_empresas_por_bolsa,
            name="listar_empresas_por_bolsa",
            description="Lista empresas disponibles en una bolsa usando Financial Modeling Prep. "
                        "Args: bolsa (str, default 'BVC') — 'BVC', 'NYSE', 'NASDAQ', 'TSE', 'LSE', 'TSX', 'XETRA'. "
                        "limite (int, default 30). sector (str, opcional) — filtrar por industria. "
                        "Retorna tabla con ticker, nombre, precio, sector.",
        ),
        StructuredTool.from_function(
            coroutine=leer_noticias_valora,
            name="leer_noticias_valora",
            description="Lee y filtra noticias financieras extraídas de Valora Analitik. "
                        "Args: archivo (ruta JSON, opcional), sector (filtrar por sector, opcional), "
                        "limite (máx noticias, opcional). Retorna JSON.",
        ),
        StructuredTool.from_function(
            coroutine=analizar_sentimiento_empresas_bvc,
            name="analizar_sentimiento_empresas_bvc",
            description="Analiza sentimiento de noticias para empresas de la BVC. "
                        "Args: archivo (ruta JSON, opcional). Retorna resumen por empresa "
                        "con valoración POSITIVA/NEGATIVA/NEUTRAL y distribución porcentual.",
        ),
        StructuredTool.from_function(
            coroutine=obtener_datos_financieros,
            name="obtener_datos_financieros",
            description="Obtiene indicadores financieros clave de una empresa vía Yahoo Finance: "
                        "P/E ratio, ROE, margen neto, EBITDA, free cash flow, market cap, precio actual. "
                        "Args: ticker (str) — nombre o símbolo bursátil (ej: 'ECOPETROL', 'EC.CL', 'PFAVAL').",
        ),
        StructuredTool.from_function(
            coroutine=predict_stock_gru,
            name="predict_stock_gru",
            description="Predice precios de cierre usando red neuronal GRU (deep learning). "
                        "Args: ticker (str), start_date (YYYY-MM-DD), end_date (YYYY-MM-DD), "
                        "lookback (int, default 30), pred_len (int, default 5). "
                        "Retorna métricas MAE/RMSE + pronóstico.",
        ),
        StructuredTool.from_function(
            coroutine=predict_stock_kronos,
            name="predict_stock_kronos",
            description="Predice precios y volumen usando Kronos (modelo fundacional de time-series). "
                        "Args: ticker (str), start_date (YYYY-MM-DD), end_date (YYYY-MM-DD), "
                        "lookback (int, default 343), pred_len (int, default 7). "
                        "NOTA: carga modelo en RAM (~2GB) en primer uso.",
        ),
        StructuredTool.from_function(
            coroutine=ejecutar_scraper_valora,
            name="ejecutar_scraper_valora",
            description="Inicia scraping de noticias financieras de Valora Analitik en background. "
                        "Args: since_days (int, default 5). "
                        "Retorna job_id. Usar obtener_estado_scraper para monitorear.",
        ),
        StructuredTool.from_function(
            coroutine=obtener_estado_scraper,
            name="obtener_estado_scraper",
            description="Consulta estado de trabajos de scraping. "
                        "Args: job_id (str, opcional). Si se omite, lista todos los trabajos.",
        ),
    ]

    return tools

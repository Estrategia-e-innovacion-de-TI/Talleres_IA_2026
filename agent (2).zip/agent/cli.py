#!/usr/bin/env python3
"""
Agente de Inversiones BVC — CLI interactivo.

Uso:
    python agent/cli.py "¿Recomiendas invertir en Ecopetrol?"
    python agent/cli.py "¿Qué me dices de Bancolombia vs Grupo Sura?"
    python agent/cli.py --model gpt-4o-mini "Analiza PFAVAL"
    python agent/cli.py --interactive   # modo conversación
"""

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path

# Asegurar que el proyecto está en el path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from agent.agent_graph import create_agent, ask
from langchain_core.messages import HumanMessage
from langgraph.types import Command


# ── logging ─────────────────────────────────────────────────

logging.basicConfig(
    level=logging.WARNING,  # Cambiar a INFO para ver tool calls
    format="%(levelname)s | %(message)s",
)


# ── main ───────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="🤖 Agente de Inversiones BVC — análisis inteligente de acciones colombianas",
    )
    parser.add_argument("query", nargs="*", help="Pregunta sobre inversiones")
    parser.add_argument(
        "--interactive", "-i",
        action="store_true",
        help="Modo interactivo (conversación continua)",
    )
    parser.add_argument(
        "--model", "-m",
        default=None,
        help="Modelo LLM (default: deepseek-chat)",
    )
    parser.add_argument(
        "--provider",
        default="openai",
        choices=["openai", "gemini", "bedrock"],
        help="Provider LLM (openai | anthropic | ollama)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Muestra logs de herramientas y progreso",
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        help="Muestra respuesta en streaming (token a token)",
    )
    parser.add_argument(
        "--tool-log", "-t",
        action="store_true",
        help="Muestra paso a paso las tools que se están ejecutando",
    )
    return parser.parse_args()


async def run_single(query: str, provider: str, model: str | None, stream: bool, tool_log: bool):
    """Ejecuta una consulta única."""
    agent = create_agent(provider=provider, model=model)

    if stream:
        config = {"configurable": {"thread_id": "cli-session"}}
        print("🤔 Analizando...\n")
        async for event in agent.astream_events(
            {"messages": [HumanMessage(content=query)]},
            config=config,
            version="v2",
        ):
            kind = event.get("event", "")
            if kind == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                if hasattr(chunk, "content") and chunk.content:
                    print(chunk.content, end="", flush=True)
        print()
    elif tool_log:
        config = {"configurable": {"thread_id": "cli-session"}}
        print("🤔 Analizando...\n")
        async for event in agent.astream_events(
            {"messages": [HumanMessage(content=query)]},
            config=config,
            version="v2",
        ):
            kind = event.get("event", "")
            name = event.get("name", "")
            if kind == "on_tool_start":
                tool_input = event["data"].get("input", {})
                print(f"\n⚙️  \033[33m{name}\033[0m({tool_input})")
            elif kind == "on_tool_end":
                print(f"   ✅ \033[32m{name} completada\033[0m")
            elif kind == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                if hasattr(chunk, "content") and chunk.content:
                    print(chunk.content, end="", flush=True)
        print()
    else:
        if tool_log:
            print("⚠️  --tool-log solo funciona con --stream activo. Activando streaming automáticamente.")
        result = await ask(query, provider=provider, model=model)
        print(result)


async def run_interactive(provider: str, model: str | None):
    """Modo interactivo con memoria de conversación."""
    agent = create_agent(provider=provider, model=model)

    print("=" * 60)
    print("🤖 AGENTE DE INVERSIONES BVC".center(60))
    print("=" * 60)
    print("Escribe tu pregunta sobre inversiones en la BVC.")
    print("Comandos: /salir, /clear, /help")
    print()

    thread_id = "interactive-1"
    config = {"configurable": {"thread_id": thread_id}}

    while True:
        try:
            query = input("📈 > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 ¡Hasta luego!")
            break

        if not query:
            continue
        if query.lower() in ("/salir", "/exit", "/quit", "/q"):
            print("👋 ¡Hasta luego!")
            break
        if query.lower() == "/clear":
            # Nueva thread para reiniciar memoria
            thread_id = f"interactive-{id(object())}"
            config = {"configurable": {"thread_id": thread_id}}
            print("🧹 Conversación reiniciada.\n")
            continue
        if query.lower() == "/help":
            print("Comandos:")
            print("  /salir   — salir")
            print("  /clear   — reiniciar conversación")
            print("  /help    — esta ayuda")
            print()
            continue

        print()
        async for event in agent.astream_events(
            {"messages": [HumanMessage(content=query)]},
            config=config,
            version="v2",
        ):
            kind = event.get("event", "")
            if kind == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                if hasattr(chunk, "content") and chunk.content:
                    print(chunk.content, end="", flush=True)
        print("\n")


async def main():
    args = parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.INFO)

    # Combinar query de argumentos posicionales
    query = " ".join(args.query)

    if args.interactive or not query:
        await run_interactive(args.provider, args.model)
    else:
        await run_single(query, args.provider, args.model, args.stream, args.tool_log)


if __name__ == "__main__":
    asyncio.run(main())

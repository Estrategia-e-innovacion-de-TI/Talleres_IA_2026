"""Financial analysis agent using LangGraph + MCP tools."""
